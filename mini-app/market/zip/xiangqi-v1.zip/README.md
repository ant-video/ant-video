# 楚河象棋

9 路 10 行中国象棋。先选棋子再选落点，合法落点用绿点标记。支持蹩马腿、塞象眼、炮架、过河、九宫、将帅照面和应将校验。将死或困毙的一方负。

- **人机对弈**由玩家执红先行，黑方机器人在工作线程搜索。可悔棋或重新开局，宿主保存局面。
- **好友对战**由房主执红，客方执黑。每步限时 120 秒，黑方视角自动翻转。可用房间码邀请好友，刷新后恢复局面。双方都走过棋后，认输或超时会给对手记一场胜利。
- **休闲棋规**同一局面第三次出现时，循环中连续单方将军则将军方负，其余重复局面判和。连续 120 步未吃子判和。重复局面按这里列出的规则处理。
- **控制**支持鼠标、触屏和宿主遥控器。电视上用方向键移动焦点，确认键选择棋子或落点。

## 安装与验证

在已开通小程序联网能力的蚂蚁影视中，打开「小程序 → + → 导入 zip 包」，选择 [xiangqi-v1.zip](../../market/zip/xiangqi-v1.zip)。

两端使用相同应用 ID `com.leospring.xiangqi`。房间、私有记录和胜场榜复用 SDK 8 接口。胜场由客户端结算，适合休闲好友对弈。

在本仓库的 `mini-app` 目录运行预检。

```sh
python3 skills/miniapp-dev/scripts/check_miniapp.py miniapps/xiangqi
```

修改源码后可从 `mini-app` 目录重新打包。

```sh
python3 -B skills/miniapp-dev/scripts/pack_miniapp.py miniapps/xiangqi -o market/zip/xiangqi-v1.zip
```
