# 数独竞速

标准九宫格数独。每行、每列和每个小宫各包含一次数字 1–9。支持入门、进阶、挑战三档，分别从 44、35、28 个提示数字开始，生成时逐步检查是否保持唯一解。

- **离线练习**支持笔记、擦除、撤销、冲突高亮和提示一格。宿主保存已填数字和笔记。
- **好友对战**双方使用同一道题，20 分钟内先提交正确棋盘者获胜，双方超时判为平局。作答草稿保存在本机，刷新或重开可以恢复。
- **好友胜场榜**展示前 50 名。获胜端同步本场胜场，断线后可重试。同一场对局只登记一次。
- **控制**用方向键选格，确认键切到数字键盘，选完数字后返回棋盘。桌面键盘也可直接按 1–9，触屏可点选空格和数字。

## 安装与验证

在已开通小程序联网能力的蚂蚁影视中，打开「小程序 → + → 导入 zip 包」，选择 [sudoku-v1.zip](../../market/zip/sudoku-v1.zip)。

两端安装相同的小程序 ID `com.leospring.sudoku`，创建房间后将房间码发给好友。应用复用 SDK 8 的房间、设备身份、私有云存储和通用排行榜，安装后即可使用宿主现有的联网服务。胜场由客户端结算，适合好友休闲对战。

在本仓库的 `mini-app` 目录运行预检。

```sh
python3 skills/miniapp-dev/scripts/check_miniapp.py miniapps/sudoku
```

浏览器可用 `python3 -m http.server 8082 --bind 127.0.0.1 --directory miniapps/sudoku` 预览离线练习。联机使用宿主 SDK，盒子真机联调待验证。

修改源码后可从 `mini-app` 目录重新打包。

```sh
python3 -B skills/miniapp-dev/scripts/pack_miniapp.py miniapps/sudoku -o market/zip/sudoku-v1.zip
```
