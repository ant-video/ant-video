(function () {
  'use strict';

  var APP_ID = 'com.leospring.cms_t4_bridge';
  var STORAGE_KEY = 'cms-t4-config';
  var nameInput = document.getElementById('name');
  var urlInput = document.getElementById('url');
  var status = document.getElementById('status');
  var output = document.getElementById('config-output');
  var current = null;

  function jsonResponse(value, statusCode) {
    return {
      status: statusCode || 200,
      headers: { 'Content-Type': 'application/json; charset=utf-8' },
      body: JSON.stringify(value)
    };
  }

  function errorResponse(code, message, statusCode) {
    return jsonResponse({ code: code, msg: message, data: null }, statusCode || 400);
  }

  function setStatus(message, kind) {
    status.textContent = message;
    status.className = 'status' + (kind ? ' ' + kind : '');
  }

  function cleanUrl(raw) {
    var value = String(raw || '').trim();
    if (!value) throw new Error('请填写 CMS JSON 接口');
    var parsed;
    try { parsed = new URL(value); } catch (e) { throw new Error('接口地址不是合法 URL'); }
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      throw new Error('接口只支持 http 或 https');
    }
    parsed.hash = '';
    return parsed.toString();
  }

  function readConfig() {
    return ant.storage.getJSON(STORAGE_KEY, null).then(function (value) {
      if (!value || !value.url) return null;
      return { name: String(value.name || 'CMS 影视源'), url: String(value.url) };
    });
  }

  function saveConfig(config) {
    current = config;
    return ant.storage.setJSON(STORAGE_KEY, config).then(function () {
      paintConfig();
      setStatus('配置已保存，T4 服务已启用。', 'ok');
    });
  }

  function paintConfig() {
    if (!current) {
      output.textContent = '尚未配置';
      return;
    }
    nameInput.value = current.name;
    urlInput.value = current.url;
    output.textContent = JSON.stringify({
      name: current.name,
      appId: APP_ID,
      type: 't4',
      url: 'miniapp://' + APP_ID,
      configUrl: 'miniapp://' + APP_ID + '/config'
    }, null, 2);
  }

  function cmsUrl(config, params) {
    var url = new URL(config.url);
    Object.keys(params || {}).forEach(function (key) {
      var value = params[key];
      if (value !== undefined && value !== null && String(value) !== '') {
        url.searchParams.set(key, String(value));
      }
    });
    return url.toString();
  }

  function categoryParams(raw) {
    var params = {
      t: raw.t,
      ac: 'videolist',
      pg: raw.pg || 1
    };
    var ext = decodeExt(raw.ext);
    Object.keys(ext || {}).forEach(function (key) {
      if (key === 't' || key === 'ac' || key === 'pg') return;
      if (ext[key] !== undefined && ext[key] !== null && String(ext[key]) !== '') {
        params[key] = ext[key];
      }
    });
    return params;
  }

  function unwrap(payload) {
    if (payload && payload.data && typeof payload.data === 'object' &&
        (payload.data.list || payload.data.class || payload.data.classes)) {
      return payload.data;
    }
    return payload || {};
  }

  function asList(value) { return Array.isArray(value) ? value : []; }

  function sourceCode(data) {
    return data && data.code !== undefined ? data.code : 0;
  }

  function sourceMessage(data) {
    return data && (data.msg || data.message) ? String(data.msg || data.message) : 'success';
  }

  function normalizeHome(payload) {
    var data = unwrap(payload);
    return {
      code: sourceCode(data),
      msg: sourceMessage(data),
      class: asList(data.class || data.classes),
      filters: data.filters || {},
      list: asList(data.list),
      page: data.page || 1,
      pagecount: data.pagecount || data.pageCount || 1,
      limit: data.limit || 0,
      total: data.total || asList(data.list).length
    };
  }

  function normalizeList(payload) {
    var data = unwrap(payload);
    return {
      code: sourceCode(data),
      msg: sourceMessage(data),
      page: data.page || 1,
      pagecount: data.pagecount || data.pageCount || 1,
      limit: data.limit || 0,
      total: data.total || asList(data.list).length,
      list: asList(data.list)
    };
  }

  function decodeExt(value) {
    if (!value) return {};
    if (typeof value === 'object') return value;
    try {
      var raw = decodeURIComponent(String(value));
      if (raw.charAt(0) === '{') return JSON.parse(raw);
    } catch (_) {}
    try {
      var text = atob(value.replace(/-/g, '+').replace(/_/g, '/'));
      var bytes = new Uint8Array(text.length);
      for (var i = 0; i < text.length; i++) bytes[i] = text.charCodeAt(i);
      return JSON.parse(new TextDecoder('utf-8').decode(bytes));
    } catch (e) {
      try { return JSON.parse(decodeURIComponent(escape(atob(value)))); } catch (_) { return {}; }
    }
  }

  function fetchJson(config, params) {
    return ant.request({
      url: cmsUrl(config, params),
      timeout: 60000,
      headers: {
        Accept: 'application/json, text/plain, */*',
        'User-Agent': 'okhttp/4.12.0'
      }
    }).then(function (response) {
      var statusCode = Number(response && response.statusCode || 0);
      var body = String(response && response.data || '').replace(/^\uFEFF/, '').trim();
      if (statusCode < 200 || statusCode >= 300) {
        var httpError = new Error('CMS HTTP ' + statusCode + (body ? ': ' + body.slice(0, 160) : ''));
        httpError.code = 'CMS_HTTP_' + statusCode;
        throw httpError;
      }
      try {
        return JSON.parse(body);
      } catch (error) {
        // 个别 CMS 会把 JSON 放进 <pre>，或返回 JSONP；尽量剥掉包装再解析。
        var candidate = body.replace(/^\s*<pre[^>]*>/i, '').replace(/<\/pre>\s*$/i, '').trim();
        var jsonp = candidate.match(/^[\w$]+\s*\((.*)\)\s*;?$/s);
        if (jsonp) candidate = jsonp[1].trim();
        try {
          return JSON.parse(candidate);
        } catch (_) {
          var parseError = new Error('CMS 返回的不是 JSON：' + (body.slice(0, 180) || '空响应'));
          parseError.code = 'CMS_INVALID_JSON';
          throw parseError;
        }
      }
    });
  }

  function handleService(req) {
    return readConfig().then(function (config) {
      var path = req.path || '/';
      if (path === '/health' || path === '/api/health') {
        return jsonResponse({ code: 0, msg: 'ok', data: { appId: APP_ID, configured: !!config } });
      }
      if (path === '/config' || path === '/api/config' || path === '/api/v1/config') {
        var descriptor = {
          key: APP_ID,
          name: config ? config.name : '',
          appId: APP_ID,
          api: 'miniapp://' + APP_ID,
          url: 'miniapp://' + APP_ID,
          type: 4,
          configured: !!config
        };
        return jsonResponse({
          code: 0,
          msg: 'success',
          data: descriptor,
          list: [descriptor]
        });
      }
      if (!config) return errorResponse('NOT_CONFIGURED', '请先在小程序内配置 CMS 接口', 503);

      var params = req.params || {};
      var ac = String(params.ac || '').toLowerCase();
      if (params.wd !== undefined && String(params.wd) !== '') {
        return fetchJson(config, { ac: 'detail', wd: params.wd, pg: params.pg || 1 })
          .then(normalizeList);
      }
      if (ac === 'detail' && params.ids !== undefined && String(params.ids) !== '') {
        return fetchJson(config, { ac: 'detail', ids: params.ids })
          .then(normalizeList);
      }
      if (params.t !== undefined && String(params.t) !== '') {
        return fetchJson(config, categoryParams(params)).then(normalizeList);
      }
      return fetchJson(config, { filter: 'true' }).then(normalizeHome);
    }).catch(function (error) {
      var message = (error && error.message) || String(error);
      return errorResponse(error && error.code ? error.code : 'UPSTREAM_FAILED', message, 502);
    });
  }

  // 先注册服务，再读配置；后台拉起时没有 DOM 也能正常处理请求。
  ant.serve(handleService);

  document.getElementById('save').addEventListener('click', function () {
    var config;
    try {
      config = { name: String(nameInput.value || '').trim() || 'CMS 影视源', url: cleanUrl(urlInput.value) };
    } catch (e) {
      setStatus(e.message, 'error');
      return;
    }
    saveConfig(config).catch(function (e) { setStatus('保存失败：' + e.message, 'error'); });
  });

  document.getElementById('test').addEventListener('click', function () {
    var config;
    try { config = { name: String(nameInput.value || '').trim() || 'CMS 影视源', url: cleanUrl(urlInput.value) }; }
    catch (e) { setStatus(e.message, 'error'); return; }
    setStatus('正在请求 CMS 首页…');
    fetchJson(config, {}).then(function (data) {
      var normalized = normalizeHome(data);
      setStatus('接口正常：返回 ' + normalized.class.length + ' 个分类、' + normalized.list.length + ' 条推荐。', 'ok');
    }).catch(function (e) { setStatus('接口测试失败：' + ((e && e.message) || e), 'error'); });
  });

  document.getElementById('reset').addEventListener('click', function () {
    ant.storage.remove(STORAGE_KEY).then(function () {
      current = null;
      nameInput.value = '';
      urlInput.value = '';
      paintConfig();
      setStatus('配置已清除，服务暂不可用。');
    }).catch(function (e) { setStatus('清除失败：' + e.message, 'error'); });
  });

  document.getElementById('copy').addEventListener('click', function () {
    if (!current) { setStatus('请先保存配置。', 'error'); return; }
    ant.clipboard.set(output.textContent).then(function () { setStatus('配置 JSON 已复制。', 'ok'); });
  });

  ant.tv.onKey(function (event) {
    var items = Array.prototype.slice.call(document.querySelectorAll('input, button:not([disabled])'));
    if (!items.length) return;
    var index = items.indexOf(document.activeElement);
    if (event.key === 'ArrowDown' || event.key === 'ArrowRight') index = (index + 1) % items.length;
    else if (event.key === 'ArrowUp' || event.key === 'ArrowLeft') index = index <= 0 ? items.length - 1 : index - 1;
    else if (event.key === 'Enter' || event.key === 'Select') { if (document.activeElement) document.activeElement.click(); return; }
    else return;
    items[index].focus();
  });

  readConfig().then(function (config) {
    current = config;
    paintConfig();
    if (current) setStatus('已加载「' + current.name + '」，T4 服务运行中。', 'ok');
  }).catch(function (e) { setStatus('读取配置失败：' + e.message, 'error'); });
})();
