/*!
 * app.js —— 配置页的交互。
 *
 * bundle（danmu-service.js）以 module 方式加载，会晚于这个脚本执行完，所以这里
 * 轮询等 `window.danmuService` 出现，而不是假定它已经在了。
 */
(function () {
  'use strict';

  var COMMON_KEYS = [
    'TOKEN', 'SOURCE_ORDER', 'PLATFORM_ORDER', 'LOG_LEVEL', 'DANMU_LIMIT',
    'DANMU_OFFSET', 'BLOCKED_WORDS', 'GROUP_MINUTE', 'MAX_ANIMES',
    'VOD_SERVERS', 'OTHER_SERVER', 'PROXY_URL', 'BILIBILI_COOKIE',
    'SEARCH_CACHE_MINUTES', 'COMMENT_CACHE_MINUTES', 'STRICT_TITLE_MATCH',
    'TITLE_TO_CHINESE', 'DANMU_SIMPLIFIED_TRADITIONAL', 'CONVERT_COLOR',
    'MERGE_SOURCE_PAIRS', 'USE_BANGUMI_DATA', 'VOD_REQUEST_TIMEOUT'
  ];

  /** 值里带这些字样的配置项在界面上打码。 */
  var SECRET_HINTS = ['TOKEN', 'KEY', 'COOKIE', 'SECRET', 'PASSWORD'];

  function $(id) { return document.getElementById(id); }

  function service() { return window.danmuService; }

  function mask(key, value) {
    var upper = String(key).toUpperCase();
    var secret = SECRET_HINTS.some(function (hint) { return upper.indexOf(hint) >= 0; });
    if (!secret || !value) return value;
    return value.length <= 4 ? '••••' : value.slice(0, 2) + '••••' + value.slice(-2);
  }

  function renderKeyOptions() {
    $('envKeys').innerHTML = COMMON_KEYS.map(function (key) {
      return '<option value="' + key + '"></option>';
    }).join('');
  }

  function renderEnv() {
    var api = service();
    var list = $('envList');
    if (!api) return;

    var env = api.env();
    var keys = Object.keys(env).sort();
    if (!keys.length) {
      list.innerHTML = '<div class="empty">还没有自定义配置，全部走默认值。</div>';
      return;
    }

    list.innerHTML = keys.map(function (key) {
      return '<div class="env-item">' +
        '<div><div class="env-key">' + escapeHtml(key) + '</div>' +
        '<div class="env-val">' + escapeHtml(mask(key, String(env[key]))) + '</div></div>' +
        '<button class="ghost" data-del="' + escapeHtml(key) + '">删除</button>' +
        '</div>';
    }).join('');

    Array.prototype.forEach.call(list.querySelectorAll('[data-del]'), function (button) {
      button.addEventListener('click', function () {
        api.setEnv(button.getAttribute('data-del'), '');
        renderEnv();
        ant.ui.toast('已删除');
      });
    });
  }

  function escapeHtml(text) {
    return String(text).replace(/[&<>"']/g, function (ch) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch];
    });
  }

  function renderStats() {
    var api = service();
    if (!api) return;
    var stats = api.stats;
    $('state').innerHTML = '<span class="dot ok"></span>已就绪';
    $('requests').textContent = String(stats.requests);
    if (stats.lastAt) {
      var status = stats.lastError ? '失败' : stats.lastStatus;
      $('last').textContent = stats.lastPath + ' → ' + status;
    }
  }

  function bind() {
    var api = service();

    $('copy').addEventListener('click', function () {
      ant.clipboard.set($('endpoint').textContent.trim()).then(function () {
        ant.ui.toast('地址已复制');
      });
    });

    $('test').addEventListener('click', function () {
      var button = $('test');
      var out = $('testOut');
      button.disabled = true;
      button.textContent = '自检中…';
      out.hidden = false;
      out.textContent = '正在向各弹幕源发起搜索，慢的话要十几秒…';

      api.selfTest().then(function (result) {
        var body = result.body || '';
        out.textContent = 'HTTP ' + result.status + '\n' +
          (body.length > 4000 ? body.slice(0, 4000) + '\n…（已截断）' : body);
        ant.ui.toast(result.status === 200 ? '自检通过' : '自检返回 ' + result.status);
      }).catch(function (e) {
        out.textContent = '自检失败: ' + ((e && e.message) || e);
        ant.ui.toast('自检失败');
      }).finally(function () {
        button.disabled = false;
        button.textContent = '自检（搜一次弹幕）';
        renderStats();
      });
    });

    $('envAdd').addEventListener('click', function () {
      var key = $('envKey').value.trim().toUpperCase();
      if (!key) {
        ant.ui.toast('先填变量名');
        return;
      }
      api.setEnv(key, $('envVal').value.trim());
      $('envKey').value = '';
      $('envVal').value = '';
      renderEnv();
      ant.ui.toast('已保存');
    });
  }

  /** bundle 是 module，晚于本脚本执行，等它把 danmuService 挂上来。 */
  function waitForService(attempt) {
    if (service()) {
      service().ready().then(function () {
        renderKeyOptions();
        renderStats();
        renderEnv();
        bind();
        setInterval(renderStats, 2000);
      });
      return;
    }
    if (attempt > 100) {
      $('state').innerHTML = '<span class="dot err"></span>服务启动失败，请查看日志';
      return;
    }
    setTimeout(function () { waitForService(attempt + 1); }, 100);
  }

  /**
   * TV 遥控：WebView 不参与系统焦点，方向键由宿主转发进来，得自己挪 focus。
   * 不处理的话电视上这个页面完全没法操作。
   */
  ant.tv.onKey(function (event) {
    var focusables = Array.prototype.slice.call(
      document.querySelectorAll('button, input')
    ).filter(function (el) { return !el.disabled && el.offsetParent !== null; });
    if (!focusables.length) return;

    var index = focusables.indexOf(document.activeElement);
    if (event.key === 'ArrowDown' || event.key === 'ArrowRight') {
      index = (index + 1) % focusables.length;
    } else if (event.key === 'ArrowUp' || event.key === 'ArrowLeft') {
      index = index <= 0 ? focusables.length - 1 : index - 1;
    } else if (event.key === 'Enter' || event.key === 'Select') {
      // 输入框上按 OK 不该触发 click（会把光标位置搞乱），交给系统输入法。
      var active = document.activeElement;
      if (active && active.tagName !== 'INPUT') active.click();
      return;
    } else {
      return;
    }
    focusables[index].focus();
    focusables[index].scrollIntoView({ block: 'nearest' });
  });

  waitForService(0);
})();
